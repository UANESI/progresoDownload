alert(1)
alert("Funciona 1")