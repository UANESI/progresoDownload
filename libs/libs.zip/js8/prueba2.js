console.log(2)
console.log("Funciona 2")