console.log(3)
console.log("Funciona 3")